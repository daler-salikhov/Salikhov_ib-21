import datetime as date
class Date:
    def __init__(self, month, day):
        self.month = month
        self.day = day

    def __sub__(self, other):
        dat1 = date.datetime(2022, self.month, self.day)
        dat2 = date.datetime(2022, other.month, other.day)
        if dat1 == dat2:
            return 0
        else:
            return str(dat1 - dat2).split()[0]

jan5 = Date(1, 5)
jan1 = Date(1, 1)

print(jan5 - jan1)
print(jan1 - jan5)
print(jan1 - jan1)
print(jan5 - jan5)