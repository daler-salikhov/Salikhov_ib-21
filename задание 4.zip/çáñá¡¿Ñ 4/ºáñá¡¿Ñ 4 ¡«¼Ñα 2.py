class ReversedList:
    def __init__(self, lst = list()):
        self.lst = lst
        lst.reverse()

    def __len__(self):
        return len(self.lst)

    def __getitem__(self, key):
        return self.lst[key]

rl = ReversedList([10])
print(len(rl))
print(rl[0])
